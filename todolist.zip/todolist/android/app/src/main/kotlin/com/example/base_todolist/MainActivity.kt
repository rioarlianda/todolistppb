package com.example.base_todolist

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
